# NeuroStitch
A toolkit for semi-automated neuron reconstruction, for refining and assembling 3D neuron segmentations derived from biological microscopy images
